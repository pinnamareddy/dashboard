import Hospitaldetails from "./hospitaldetails";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadHospitals } from "../../store/actions/hospitals";
import DeleteModal from "../../components/deletemodal/deleteModal";
import axios from "axios";
import { deleteHospitalApi } from "../../constant";
const headers = [
  {
    id: "name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "specialization",
    numeric: false,
    disablePadding: false,
    label: "Specialization",
  },
  {
    id: "department",
    numeric: false,
    disablePadding: false,
    label: "Department",
  },
  {
    id: "phone",
    numeric: false,
    disablePadding: false,
    label: "Phone",
  },
  {
    id: "Created_on",
    numeric: false,
    disablePadding: false,
    label: "Created On",
  }
 
];

export class Hospitals extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getHospitalsList, Login } = this.props;
    // console.log(Hospitals);
    getHospitalsList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      }
      else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };

  deletehospital = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getHospitalsList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const hospital = {
        hospital_id: this.state.selected[0],
      };

      const data = Object.keys(hospital)
        .map((key) => `${key}=${encodeURIComponent(hospital[key])}`)
        .join("&");

      const hospitalDelete = await axios({
        method: "post",
        url: deleteHospitalApi,
        data: data,
        headers: headers,
      });
      if (hospitalDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: hospitalDelete.data.message,
          alert: true,
        });
        getHospitalsList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        hospitalDelete.data.status === 201 ||
        hospitalDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: hospitalDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };
  handleModal = (value) => {
    this.setState({ open: value });
  };
  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };

  render() {
    const { Hospitals } = this.props;
    const {  open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType, } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Hospitals"
          headCell={headers}
          data={Hospitals.data}
          handleButtonClick={this.ordersClick}
        />
     
          <Hospitaldetails
            openModel={open}
            handleModelClose={this.handleModal}
            selected={selected}
          />
      <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deletehospital}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />
        
      </div>
    );
  }
}

const mapStateToProps = ({ Hospitals, Login }) => ({ Hospitals, Login });

const mapDispatchToProps = (dispatch) => ({
   getHospitalsList: (object) => dispatch(loadHospitals(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Hospitals);
