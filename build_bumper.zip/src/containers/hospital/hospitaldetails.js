import React, { useEffect } from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addhospitalApi, editHospitalApi } from "../../constant";
import { loadHospitals } from "../../store/actions/hospitals";
// import { loadStores } from "../../store/actions/hospital";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Typography } from "@mui/material";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function Hospitaldetails(props) {
  const [hospitalObject, setHospitalsObject] = React.useState({
    name: "",
    email: "",
    password: "",
    department: "",
    address: "",
    location: "",
    phone: "",
    specialization: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getHospitalsList, Hospitals, selected } =
    props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  useEffect(() => {
    Hospitals.data.map((it) => {
      if (it._id === selected[0]) {
        setHospitalsObject(it);
      }
    });
  }, [Hospitals, selected]);

  const handleChange = (name, event) => {
    setHospitalsObject({ ...hospitalObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setHospitalsObject({
      name: "",
      email: "",
      password: "",
      department: "",
      address: "",
      location: "",
      phone: "",
      specialization: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "multipart/form-data",
      token: Login.data.token,
    };
    const bodyFormData = new FormData();
    bodyFormData.append("name", hospitalObject.name);
    bodyFormData.append("email", hospitalObject.email);
    bodyFormData.append("password", hospitalObject.password);
    bodyFormData.append("department", hospitalObject.department);
    bodyFormData.append("address", hospitalObject.address);
    bodyFormData.append("location", hospitalObject.location);
    bodyFormData.append("phone", hospitalObject.phone);
    bodyFormData.append("specialization", hospitalObject.specialization);

    if (hospitalObject._id) {
      try {
        bodyFormData.append("hospital_id", hospitalObject._id);
       
        const addStores = await axios({
          method: "post",
          url: editHospitalApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        //console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getHospitalsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getHospitalsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      try {
        const addStores = await axios({
          method: "post",
          url: addhospitalApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        //console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getHospitalsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getHospitalsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }
  };
  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  // console.log(hospitalObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Hopital Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <Grid container spacing={2}>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Name"
                    placeholder="Enter Name"
                    multiline
                    fullWidth
                    value={hospitalObject.name}
                    onChange={(e) => handleChange("name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Email"
                    placeholder="Enter Email"
                    multiline
                    fullWidth
                    value={hospitalObject.email}
                    onChange={(e) => handleChange("email", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Department"
                    placeholder="Enter Department"
                    multiline
                    fullWidth
                    value={hospitalObject.department}
                    onChange={(e) => handleChange("department", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Address"
                    placeholder="Enter Address"
                    multiline
                    rows={4.4}
                    fullWidth
                    value={hospitalObject.address}
                    onChange={(e) => handleChange("address", e)}
                    style={{ margin: 10 }}
                  />
                  
                </Grid>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Specialization"
                    placeholder="Enter Specialization"
                    multiline
                    fullWidth
                    value={hospitalObject.specialization}
                    onChange={(e) => handleChange("specialization", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Password"
                    placeholder="Enter Password"
                    multiline
                    fullWidth
                    value={hospitalObject.password}
                    onChange={(e) => handleChange("password", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Phone"
                    placeholder="Enter Phone"
                    multiline
                    fullWidth
                    value={hospitalObject.phone}
                    onChange={(e) => handleChange("phone", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Location"
                    placeholder="Enter Location"
                    multiline
                    fullWidth
                    value={hospitalObject.location}
                    onChange={(e) => handleChange("location", e)}
                    style={{ margin: 10 }}
                  />
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login, Hospitals }) => ({ Login, Hospitals });

const mapDispatchToProps = (dispatch) => ({
  // getStoresList: (object) => dispatch(loadStores(object)),
  getHospitalsList: (object) => dispatch(loadHospitals(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Hospitaldetails);
