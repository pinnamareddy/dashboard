import Doctordetails from "./doctordetail";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadDoctors } from "../../store/actions/doctors";
import DeleteModal from "../../components/deletemodal/deleteModal";
import axios from "axios";
import { deleteDoctorApi } from "../../constant";

const headers = [
  {
    id: "first_name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "designation",
    numeric: false,
    disablePadding: false,
    label: "Description",
  },
  {
    id: "department",
    numeric: false,
    disablePadding: false,
    label: "Department",
  },
  {
    id: "specialization",
    numeric: false,
    disablePadding: false,
    label: "Specialization",
  },
  {
    id: "Created_on",
    numeric: true,
    disablePadding: false,
    label: "Created on",
  },
];

export class Doctors extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getDoctorsList, Login } = this.props;
    getDoctorsList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      } else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };

  deletedoctor = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getDoctorsList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const doctor = {
        doctor_id: this.state.selected[0],
      };

      const data = Object.keys(doctor)
        .map((key) => `${key}=${encodeURIComponent(doctor[key])}`)
        .join("&");

      const doctorDelete = await axios({
        method: "post",
        url: deleteDoctorApi,
        data: data,
        headers: headers,
      });
      if (doctorDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: doctorDelete.data.message,
          alert: true,
        });
        getDoctorsList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        doctorDelete.data.status === 201 ||
        doctorDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: doctorDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };
  handleModal = (value) => {
    this.setState({ open: value });
  };

  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };

  render() {
    const { Doctors } = this.props;
    const {
      open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType,
    } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Doctor"
          headCell={headers}
          data={Doctors.data}
          handleButtonClick={this.ordersClick}
        />
        <Doctordetails
          openModel={open}
          handleModelClose={this.handleModal}
          selected={selected}
        />
        <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deletedoctor}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />
      </div>
    );
  }
}

const mapStateToProps = ({ Doctors, Login }) => ({ Doctors, Login });

const mapDispatchToProps = (dispatch) => ({
  getDoctorsList: (object) => dispatch(loadDoctors(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Doctors);
