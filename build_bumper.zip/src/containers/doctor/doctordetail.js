import React, { useEffect } from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
// import { addStoresApi } from "../../constant";
import {
  adddoctorApi,
  editDoctorApi,
  imageurl,
  uploadImageUrl,
} from "../../constant";
// import { loadStores } from "../../store/actions/stores";
import { loadDoctors } from "../../store/actions/doctors";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Typography } from "@mui/material";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function Doctordetails(props) {
  const [doctorObject, setDoctorsObject] = React.useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    designation: "",
    department: "",
    address: "",
    phone: "",
    mobile: "",
    shortbiography: "",
    profile_image: "",
    specialization: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getDoctorsList, Doctors, selected } =
    props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  useEffect(() => {
    Doctors.data.map((it) => {
      if (it._id === selected[0]) {
        setDoctorsObject(it);
      }
    });
  }, [Doctors, selected]);

  const onImageUpload = async (event) => {
    setBackdropOpen(true);
    let files = Object.values(event.target.files);

    if (files[0] && files[0].size > 1000000) {
      setErrorType("error");
      setMessage("This image size is more than 1mb.");
      setAlert(true);
      setBackdropOpen(false);
    } else {
      let bodyFormData = new FormData();
      bodyFormData.append("multiple_images", files[0]);
      // bodyFormData.getAll("multiple_images")
      try {
        let imageUpload = await axios({
          method: "post",
          url: uploadImageUrl, //"http://107.180.105.183:8445/uploadimage",
          data: bodyFormData,
          headers: { "Content-Type": "multipart/form-data" },
        });
        if (!imageUpload)
          throw "Unable to Lists from database. API error, try again";
        if (200 === imageUpload.status) {
          console.log(imageUpload);
          let splitArray = imageUpload.data.split(",");
          let url = splitArray[0];
          // console.log(url);
          setDoctorsObject({ ...doctorObject, profile_image: url });
          setBackdropOpen(false);
        }
        if (502 === imageUpload.status)
          throw "Server Error. Please reload and try again!!";
      } catch (err) {
        console.log(err);
      }
    }
  };
  const handleChange = (name, event) => {
    setDoctorsObject({ ...doctorObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setDoctorsObject({
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      designation: "",
      department: "",
      address: "",
      phone: "",
      mobile: "",
      shortbiography: "",
      profile_image: "",
      specialization: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "multipart/form-data",
      token: Login.data.token,
    };

    const bodyFormData = new FormData();
    bodyFormData.append("first_name", doctorObject.first_name);
    bodyFormData.append("last_name", doctorObject.last_name);
    bodyFormData.append("email", doctorObject.email);
    bodyFormData.append("password", doctorObject.password);
    bodyFormData.append("designation", doctorObject.designation);
    bodyFormData.append("department", doctorObject.department);
    bodyFormData.append("address", doctorObject.address);
    bodyFormData.append("phone", doctorObject.phone);
    bodyFormData.append("mobile", doctorObject.mobile);
    bodyFormData.append("shortbiography", doctorObject.shortbiography);
    bodyFormData.append("profile_image", doctorObject.profile_image);
    bodyFormData.append("specialization", doctorObject.specialization);

    if (doctorObject._id) {
      try {
        bodyFormData.append("doctor_id", doctorObject._id);
        const editStores = await axios({
          method: "post",
          url: editDoctorApi,
          data: bodyFormData,
          headers: headers,
        });
        if (editStores.data.status === 200) {
          getDoctorsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(editStores.data.message);
          setAlert(true);
        } else if (editStores.data.status === 201) {
          getDoctorsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(editStores.data.message);
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      try {
        const addStores = await axios({
          method: "post",
          url: adddoctorApi,
          data: bodyFormData,
          headers: headers,
        });
        //console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getDoctorsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getDoctorsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);

          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }
  };

  const deleteImage = () => {
    setDoctorsObject({ ...doctorObject, profile_image: "" });
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  // console.log(doctorObject.first_name);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Doctor Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <Grid container spacing={2}>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="First Name"
                    placeholder="Enter First Name"
                    multiline
                    fullWidth
                    value={doctorObject.first_name}
                    onChange={(e) => handleChange("first_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Email"
                    placeholder="Enter Email"
                    multiline
                    fullWidth
                    value={doctorObject.email}
                    onChange={(e) => handleChange("email", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Phone Number "
                    placeholder="Enter Phone Number "
                    multiline
                    fullWidth
                    value={doctorObject.phone}
                    onChange={(e) => handleChange("phone", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Designation"
                    placeholder="Enter Designation"
                    multiline
                    fullWidth
                    value={doctorObject.designation}
                    onChange={(e) => handleChange("designation", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Short Biography"
                    placeholder="Enter Short Biography"
                    multiline
                    rows={4.4}
                    fullWidth
                    value={doctorObject.shortbiography}
                    onChange={(e) => handleChange("shortbiography", e)}
                    style={{ margin: 10 }}
                  />
                  <input
                    style={{
                      marginLeft: "10px",
                    }}
                    type="file"
                    accept="image/*"
                    onChange={(evt) => onImageUpload(evt)}
                  />
                  {doctorObject.profile_image !== "" && (
                    <div
                      style={{
                        position: "relative",
                        margin: 10,
                      }}
                    >
                      <img
                        src={imageurl + doctorObject.profile_image}
                        style={{ height: 100 }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          top: "0%",
                          left: "100%",
                        }}
                      >
                        <div
                          style={{ cursor: "pointer" }}
                          onClick={() => deleteImage()}
                        >
                          <CloseIcon style={{ fontSize: "20px" }} />
                        </div>
                      </div>
                    </div>
                  )}
                </Grid>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Last Name"
                    placeholder="Enter Last Name"
                    multiline
                    fullWidth
                    value={doctorObject.last_name}
                    onChange={(e) => handleChange("last_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Password"
                    placeholder="Enter Password"
                    multiline
                    fullWidth
                    value={doctorObject.password}
                    onChange={(e) => handleChange("password", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Mobile Number"
                    placeholder="Enter Mobile Number"
                    multiline
                    fullWidth
                    value={doctorObject.mobile}
                    onChange={(e) => handleChange("mobile", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Department"
                    placeholder="Enter Department"
                    multiline
                    fullWidth
                    value={doctorObject.department}
                    onChange={(e) => handleChange("department", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Specialization"
                    placeholder="Enter Specialization"
                    multiline
                    fullWidth
                    value={doctorObject.specialization}
                    onChange={(e) => handleChange("specialization", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Address"
                    placeholder="Enter Address"
                    fullWidth
                    value={doctorObject.address}
                    onChange={(e) => handleChange("address", e)}
                    style={{ margin: 10 }}
                  />
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login, Doctors }) => ({ Login, Doctors });

const mapDispatchToProps = (dispatch) => ({
  getDoctorsList: (object) => dispatch(loadDoctors(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Doctordetails);
