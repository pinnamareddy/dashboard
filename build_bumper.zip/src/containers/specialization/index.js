import Specializationdetails from "./specializationdetails";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadSpecializations } from "../../store/actions/specializations";
import DeleteModal from "../../components/deletemodal/deleteModal";
import axios from "axios";
import { deleteSpecializationApi } from "../../constant";
const headers = [
  {
    id: "title",
    numeric: false,
    disablePadding: true,
    label: "title",
  },
  {
    id: "description",
    numeric: false,
    disablePadding: false,
    label: "Description",
  },
  {
    id: "created_by",
    numeric: false,
    disablePadding: false,
    label: "created_by",
  },
];

export class Specializations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getSpecializationsList, Login, Specializations } = this.props;
    console.log(Specializations);
    getSpecializationsList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      }else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };
  deletespecialization = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getSpecializationsList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const specialization = {
        specialization_id: this.state.selected[0],
      };

      const data = Object.keys(specialization)
        .map((key) => `${key}=${encodeURIComponent(specialization[key])}`)
        .join("&");

      const specializationDelete = await axios({
        method: "post",
        url: deleteSpecializationApi,
        data: data,
        headers: headers,
      });
      if (specializationDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: specializationDelete.data.message,
          alert: true,
        });
        getSpecializationsList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        specializationDelete.data.status === 201 ||
        specializationDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: specializationDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };
  handleModal = (value) => {
    this.setState({ open: value });
  };
  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };


  render() {
    const { Specializations } = this.props;
    const { open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType, 
    } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
      
        <Datatable
          name="Specializations"
          headCell={headers}
          data={Specializations.data}
          handleButtonClick={this.ordersClick}
        />
          <Specializationdetails
            openModel={open}
            handleModelClose={this.handleModal}
            selected={selected}
          />
          <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deletespecialization}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />
  
       
      </div>
    );
  }
}

const mapStateToProps = ({ Specializations, Login }) => ({
  Specializations,
  Login,
});

const mapDispatchToProps = (dispatch) => ({
  getSpecializationsList: (object) => dispatch(loadSpecializations(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Specializations);
