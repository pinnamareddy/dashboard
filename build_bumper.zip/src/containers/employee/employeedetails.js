import React, { useEffect } from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addemployeeApi, editEmployeeApi } from "../../constant";
import { loadEmployees } from "../../store/actions/employees";
// import { addStoresApi } from "../../constant";
// import { loadStores } from "../../store/actions/stores";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Typography } from "@mui/material";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function Employeedetails(props) {
  const [employeeObject, setEmployeesObject] = React.useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    phone: "",
    screen: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getEmployeesList, Employees, selected } =
    props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  useEffect(() => {
    Employees.data.map((it) => {
      if (it._id === selected[0]) {
        setEmployeesObject(it);
      }
    });
  }, [Employees, selected]);

  const handleChange = (name, event) => {
    setEmployeesObject({ ...employeeObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setEmployeesObject({
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      phone: "",
      screen: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      token: Login.data.token,
    };

    if (employeeObject._id) {
      const dataObject = {
        first_name: employeeObject.first_name,
        last_name: employeeObject.last_name,
        email: employeeObject.email,
        phone: employeeObject.phone,
        screen: employeeObject.screen,
        employee_id: employeeObject._id,
      };
      const data = Object.keys(dataObject)
        .map((key) => `${key}=${encodeURIComponent(dataObject[key])}`)
        .join("&");
      try {
        // bodyFormData.append("employee_id", employeeObject._id);
        const addStores = await axios({
          method: "post",
          url: editEmployeeApi,
          data: data,
          headers: headers,
        });
        if (addStores.data.status === 200) {
          getEmployeesList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getEmployeesList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage("Store added Successfully!");
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      const data = Object.keys(employeeObject)
        .map((key) => `${key}=${encodeURIComponent(employeeObject[key])}`)
        .join("&");
      try {
        const addStores = await axios({
          method: "post",
          url: addemployeeApi,
          data: data,
          headers: headers,
        });
        // console.log(addStores);
        if (addStores.data.status === 200) {
          getEmployeesList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getEmployeesList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage("Store added Successfully!");
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  // console.log(storesObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Employee Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <Grid container spacing={2}>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="First Name"
                    placeholder="Enter First Name"
                    multiline
                    fullWidth
                    value={employeeObject.first_name}
                    onChange={(e) => handleChange("first_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Email"
                    placeholder="Enter Email"
                    multiline
                    fullWidth
                    value={employeeObject.email}
                    onChange={(e) => handleChange("email", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Phone Number"
                    placeholder="Enter Phone Number"
                    multiline
                    fullWidth
                    value={employeeObject.phone}
                    onChange={(e) => handleChange("phone", e)}
                    style={{ margin: 10 }}
                  />
                </Grid>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Last Name"
                    placeholder="Enter Last Name"
                    multiline
                    fullWidth
                    value={employeeObject.last_name}
                    onChange={(e) => handleChange("last_name", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Password"
                    placeholder="Enter Password"
                    multiline
                    fullWidth
                    value={employeeObject.password}
                    onChange={(e) => handleChange("password", e)}
                    style={{ margin: 10 }}
                  />
                  {/* <TextField
                    id="outlined-textarea"
                    label="Screen"
                    placeholder="Enter Screen"
                    multiline
                    fullWidth
                    value={employeeObject.screen}
                    onChange={(e) => handleChange("screen", e)}
                    style={{ margin: 10 }}
                  /> */}
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login, Employees }) => ({ Login, Employees });

const mapDispatchToProps = (dispatch) => ({
  getEmployeesList: (object) => dispatch(loadEmployees(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Employeedetails);
