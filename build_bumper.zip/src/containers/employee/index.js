import Employeedetails from "./employeedetails";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadEmployees } from "../../store/actions/employees";
import DeleteModal from "../../components/deletemodal/deleteModal";
import axios from "axios";
import { deleteEmployeeApi } from "../../constant";

const headers = [
  {
    id: "first_name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "email",
    numeric: false,
    disablePadding: false,
    label: "Email",
  },
  {
    id: "phone",
    numeric: true,
    disablePadding: false,
    label: "Phone",
  },
  {
    id: "Created_on",
    numeric: true,
    disablePadding: false,
    label: "Created On",
  },
];

export class Employees extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getemployeesList, Login } = this.props;
    getemployeesList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      } else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };

  deleteemployee = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getemployeesList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const employee = {
        employee_id: this.state.selected[0],
      };

      const data = Object.keys(employee)
        .map((key) => `${key}=${encodeURIComponent(employee[key])}`)
        .join("&");

      const employeeDelete = await axios({
        method: "post",
        url: deleteEmployeeApi,
        data: data,
        headers: headers,
      });
      if (employeeDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: employeeDelete.data.message,
          alert: true,
        });
        getemployeesList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        employeeDelete.data.status === 201 ||
        employeeDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: employeeDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };

  handleModal = (value) => {
    this.setState({ open: value });
  };
  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };
  render() {
    const { Employees } = this.props;
    const {
      open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType,
    } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Employee"
          headCell={headers}
          data={Employees.data}
          handleButtonClick={this.ordersClick}
        />
              
        <Employeedetails openModel={open} handleModelClose={this.handleModal}  selected={selected}/>
        <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deleteemployee}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />

      </div>
    );
  }
}

const mapStateToProps = ({ Employees, Login }) => ({ Employees, Login });

const mapDispatchToProps = (dispatch) => ({
  getemployeesList: (object) => dispatch(loadEmployees(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Employees);
