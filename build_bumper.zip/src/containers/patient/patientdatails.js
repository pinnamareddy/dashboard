import React, { useEffect } from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addpatientApi, uploadImageUrl, editPatientApi, imageurl } from "../../constant";
import { loadPatients } from "../../store/actions/patients";
// import { loadStores } from "../../store/actions/patient";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Typography } from "@mui/material";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function Patientdetails(props) {
  const [patientObject, setPatientsObject] = React.useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    phone: "",
    mobile: "",
    address: "",
    actionrequired: "",
    problem: "",
    patient_image: "",
    assignpatient: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getPatientsList, Patients, selected } =
    props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  useEffect(() => {
    Patients.data.map((it) => {
      if (it._id === selected[0]) {
        setPatientsObject(it);
      }
    });
  }, [Patients, selected]);

  const onImageUpload = async (event) => {
    setBackdropOpen(true);
    let files = Object.values(event.target.files);

    if (files[0] && files[0].size > 1000000) {
      setErrorType("error");
      setMessage("This image size is more than 1mb.");
      setAlert(true);
      setBackdropOpen(false);
    } else {
      let bodyFormData = new FormData();
      bodyFormData.append("multiple_images", files[0]);
      // bodyFormData.getAll("multiple_images")
      try {
        let imageUpload = await axios({
          method: "post",
          url: uploadImageUrl, //"http://107.180.105.183:8445/uploadimage",
          data: bodyFormData,
          headers: { "Content-Type": "multipart/form-data" },
        });
        if (!imageUpload)
          throw "Unable to Lists from database. API error, try again";
        if (200 === imageUpload.status) {
          console.log(imageUpload);
          let splitArray = imageUpload.data.split(",");
          let url = splitArray[0];
          console.log(url);
          setPatientsObject({ ...patientObject, patient_image: url });
          setBackdropOpen(false);
        }
        if (502 === imageUpload.status)
          throw "Server Error. Please reload and try again!!";
      } catch (err) {
        console.log(err);
        // if (err.response.data) {
        //   setErrorType("error");
        //   setMessage(err.response.data.message);
        //   setAlert(true);
        //   setBackdropOpen(false);
        // } else {
        //   setErrorType("error");
        //   setMessage("Can't upload image!");
        //   setAlert(true);
        //   setBackdropOpen(false);
        // }
      }
    }
  };

  const handleChange = (name, event) => {
    setPatientsObject({ ...patientObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setPatientsObject({
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      problem: "",
      address: "",
      phone: "",
      mobile: "",
      actionrequired: "",
      patient_image: "",
      assignpatient: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "multipart/form-data",
      token: Login.data.token,
    };

    const data = {
      email: patientObject.email,
      password: patientObject.password,
      first_name: patientObject.first_name,
      last_name: patientObject.last_name,
      address: patientObject.address,
      phone: patientObject.phone,
      mobile: patientObject.mobile,
      actionrequired: patientObject.actionrequired,
      problem: patientObject.problem,
      patient_image: patientObject.patient_image,
      assignpatient: patientObject.assignpatient,
    };

    const bodyFormData = new FormData();
    bodyFormData.append("first_name", patientObject.first_name);
    bodyFormData.append("last_name", patientObject.last_name);
    bodyFormData.append("email", patientObject.email);
    bodyFormData.append("password", patientObject.password);
    bodyFormData.append("address", patientObject.address);
    bodyFormData.append("phone", patientObject.phone);
    bodyFormData.append("mobile", patientObject.mobile);
    bodyFormData.append("actionrequired", patientObject.actionrequired);
    bodyFormData.append("problem", patientObject.problem);
    bodyFormData.append("patient_image", patientObject.patient_image);
    bodyFormData.append("assignpatient", patientObject.assignpatient);
    if (patientObject._id) {
      try {
        bodyFormData.append("patient_id", patientObject._id);
        const addStores = await axios({
          method: "post",
          url: editPatientApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        // console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getPatientsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getPatientsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);

          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    } else {
      try {
        const addStores = await axios({
          method: "post",
          url: addpatientApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        // console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getPatientsList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getPatientsList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);

          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }
  };

  const deleteImage = () => {
    setPatientsObject({ ...patientObject, patient_image: "" });
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  console.log(patientObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Patient Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <Grid container spacing={2}>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="First Name"
                    placeholder="Enter First Name"
                    multiline
                    fullWidth
                    value={patientObject.first_name}
                    onChange={(e) => handleChange("first_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Email"
                    placeholder="Enter Email"
                    multiline
                    fullWidth
                    value={patientObject.email}
                    onChange={(e) => handleChange("email", e)}
                    style={{ margin: 10 }}
                  />
                   <TextField
                    id="outlined-textarea"
                    label="Phone Number"
                    placeholder="Enter Phone number"
                    multiline
                    fullWidth
                    value={patientObject.mobile}
                    onChange={(e) => handleChange("mobile", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Address"
                    placeholder="Enter Address"
                    multiline
                    rows={4.4}
                    fullWidth
                    value={patientObject.address}
                    onChange={(e) => handleChange("address", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Action Required"
                    placeholder="Enter Action Required"
                    multiline
                    fullWidth
                    value={patientObject.actionrequired}
                    onChange={(e) => handleChange("actionrequired", e)}
                    style={{ margin: 10 }}
                  />
                     <input
                    style={{
                      marginTop:15,
                      marginLeft: 10,
                    }}
                    type="file"
                    accept="image/*"
                    onChange={(evt) => onImageUpload(evt)}
                  />
                  {patientObject.patient_image !== "" && (
                    <div
                      style={{
                        position: "relative",
                        margin: 10,
                      }}
                    >
                      <img
                        src={imageurl + patientObject.patient_image}
                        style={{height: 100 }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          top: "0%",
                          left: "100%",
                        }}
                      >
                        <div
                          style={{ cursor: "pointer" }}
                          onClick={() => deleteImage()}
                        >
                          <CloseIcon style={{ fontSize: "20px" }} />
                        </div>
                      </div>
                    </div>
                  )}
                  
                </Grid>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Last Name"
                    placeholder="Enter Last Name"
                    multiline
                    fullWidth
                    value={patientObject.last_name}
                    onChange={(e) => handleChange("last_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Password"
                    placeholder="Enter password"
                    multiline
                    fullWidth
                    value={patientObject.password}
                    onChange={(e) => handleChange("password", e)}
                    style={{ margin: 10 }}
                  />
                 
                  <TextField
                    id="outlined-textarea"
                    label="Mobile Number"
                    placeholder="Enter Mobile number"
                    multiline
                    fullWidth
                    value={patientObject.phone}
                    onChange={(e) => handleChange("phone", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Problem"
                    placeholder="Enter Problem"
                    multiline
                    fullWidth
                    value={patientObject.problem}
                    onChange={(e) => handleChange("problem", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Assign Patient"
                    placeholder="Enter Assign Patient"
                    multiline
                    fullWidth
                    value={patientObject.assignpatient}
                    onChange={(e) => handleChange("assignpatient", e)}
                    style={{ margin: 10 }}
                  />
               
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop open={backdropOpen} onClick={handleClose}>
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login, Patients }) => ({ Login, Patients });

const mapDispatchToProps = (dispatch) => ({
  getPatientsList: (object) => dispatch(loadPatients(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Patientdetails);
