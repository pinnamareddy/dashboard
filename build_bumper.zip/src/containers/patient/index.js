import Patientdetails from "./patientdatails";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import DeleteModal from "../../components/deletemodal/deleteModal";
import { loadPatients } from "../../store/actions/patients";
import axios from "axios";
import { deletePatientApi } from "../../constant";

const headers = [
  {
    id: "first_name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "email",
    numeric: false,
    disablePadding: false,
    label: "Email",
  },
  {
    id: "phone",
    numeric: false,
    disablePadding: false,
    label: "Phone",
  },
  {
    id: "assignpatient",
    numeric: false,
    disablePadding: false,
    label: "Assign Patient",
  },
  {
    id: "createddt",
    numeric: true,
    disablePadding: false,
    label: "Created on",
  },
];

export class Patients extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getPatientsList, Login } = this.props;
    getPatientsList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      } else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };
  deletepatient = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getPatientsList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const patient = {
        patient_id: this.state.selected[0],
        
      };

      const data = Object.keys(patient)
        .map((key) => `${key}=${encodeURIComponent(patient[key])}`)
        .join("&");

      const patientDelete = await axios({
        method: "post",
        url: deletePatientApi,
        data: data,
        headers: headers,
      });
      if (patientDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: patientDelete.data.message,
          alert: true,
        });
        getPatientsList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        patientDelete.data.status === 201 ||
        patientDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: patientDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };

  handleModal = (value) => {
    this.setState({ open: value });
  };
  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };

  render() {
    const { Patients } = this.props;
    const {
      open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType,
    } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        {/* {console.log(Patients.data)} */}
        <Datatable
          name="Patient"
          headCell={headers}
          data={Patients.data}
          handleButtonClick={this.ordersClick}
        />
        {/* {console.log(Patients.data)} */}

        <Patientdetails
          openModel={open}
          handleModelClose={this.handleModal}
          selected={selected}
        />
        <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deletepatient}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />
      </div>
    );
  }
}

const mapStateToProps = ({ Patients, Login }) => ({ Patients, Login });

const mapDispatchToProps = (dispatch) => ({
  getPatientsList: (object) => dispatch(loadPatients(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Patients);
