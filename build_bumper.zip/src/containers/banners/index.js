import BannersModal from "./bannersModal";
import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadBanners } from "../../store/actions/banners";
import DeleteModal from "../../components/deletemodal/deleteModal";
import axios from "axios";
import { deleteBannerApi } from "../../constant";

const headers = [
  {
    id: "name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "type",
    numeric: false,
    disablePadding: true,
    label: "type",
  },
  {
    id: "created_on",
    numeric: true,
    disablePadding: false,
    label: "Created On",
  },
];

export class Banners extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
      deleteModal: false,
      deleteBackdrop: false,
      errorType: "",
      message: "",
      alert: false,
      selectedName: "",
      selected: [],
    };
  }

  componentDidMount() {
    const { getBannersList, Login } = this.props;
    getBannersList({ token: Login.data.token });
  }

  ordersClick = (value, selected, name) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      } else if (value === "edit") {
        this.setState({ open: true, selected: selected });
      } else {
        this.setState({
          deleteModal: true,
          selected: selected,
          selectedName: name,
        });
      }
    });
  };
  deletebanner = async () => {
    this.setState({ deleteBackdrop: true });
    try {
      const { Login, getBannersList } = this.props;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        token: Login.data.token,
      };

      const banner = {
        banner_id: this.state.selected[0],
      };

      const data = Object.keys(banner)
        .map((key) => `${key}=${encodeURIComponent(banner[key])}`)
        .join("&");

      const bannerDelete = await axios({
        method: "post",
        url: deleteBannerApi,
        data: data,
        headers: headers,
      });
      if (bannerDelete.data.status === 200) {
        this.setState({
          deleteBackdrop: false,
          errorType: "success",
          message: bannerDelete.data.message,
          alert: true,
        });
        getBannersList({ token: Login.data.token });
        this.handleDeleteModal(false);
      } else if (
        bannerDelete.data.status === 201 ||
        bannerDelete.data.status === 500
      ) {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: bannerDelete.data.message,
          alert: true,
        });
      } else {
        this.setState({
          deleteBackdrop: false,
          errorType: "error",
          message: "Error!, Please contact your Administrator!!",
          alert: true,
        });
      }
    } catch (error) {
      this.setState({
        deleteBackdrop: false,
        errorType: "error",
        message: "Error!, Please contact your Administrator!!",
        alert: true,
      });
    }
  };
  handleModal = (value) => {
    this.setState({ open: value });
  };
  handleBackdrop = (value) => {
    this.setState({ deleteBackdrop: value });
  };

  handlealert = (value) => {
    this.setState({ alert: value });
  };

  handleDeleteModal = (value) => {
    this.setState({ deleteModal: value });
  };

  render() {
    const { Banners } = this.props;
    const {
      open,
      selected,
      deleteModal,
      selectedName,
      deleteBackdrop,
      alert,
      message,
      errorType,
    } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Banners"
          headCell={headers}
          data={Banners.data}
          handleButtonClick={this.ordersClick}
        />

        <BannersModal
          openModel={open}
          handleModelClose={this.handleModal}
          selected={selected}
        />
        <DeleteModal
          openModal={deleteModal}
          name={selectedName}
          backdropOpen={deleteBackdrop}
          handledelete={this.deletebanner}
          handleCloseModal={this.handleDeleteModal}
          handleBackdrop={this.handleBackdrop}
          handleAlert={this.handlealert}
          errorType={errorType}
          message={message}
          alert={alert}
        />
      </div>
    );
  }
}

const mapStateToProps = ({ Banners, Login }) => ({ Banners, Login });

const mapDispatchToProps = (dispatch) => ({
  getBannersList: (object) => dispatch(loadBanners(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Banners);
