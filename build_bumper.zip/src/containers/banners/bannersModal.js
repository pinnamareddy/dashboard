import  React ,{ useEffect }from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addbannerApi, editBannerApi,uploadImageUrl } from "../../constant";
import { loadBanners } from "../../store/actions/banners";

import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";

import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function BannersModal(props) {
  const [bannerObject, setBannersObject] = React.useState({
    name: "",
    type: "",
    user_id:"",
    banner_image: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getBannersList,Banners, selected  } = props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  useEffect(() => {
    Banners.data.map((it) => {
      if (it._id === selected[0]) {
        setBannersObject(it);
      }
    });
  }, [Banners, selected]);

  
  const onImageUpload = async (event) => {
    setBackdropOpen(true);
    let files = Object.values(event.target.files);

    if (files[0] && files[0].size > 1000000) {
      setErrorType("error");
      setMessage("This image size is more than 1mb.");
      setAlert(true);
      setBackdropOpen(false);
    } else {
      let bodyFormData = new FormData();
      bodyFormData.append("multiple_images", files[0]);
      // bodyFormData.getAll("multiple_images")
      try {
        let imageUpload = await axios({
          method: "post",
          url: uploadImageUrl, //"http://107.180.105.183:8445/uploadimage",
          data: bodyFormData,
          headers: { "Content-Type": "multipart/form-data" },
        });
        if (!imageUpload)
          throw "Unable to Lists from database. API error, try again";
        if (200 === imageUpload.status) {
          console.log(imageUpload);
          let splitArray = imageUpload.data.split(",");
          let url = splitArray[0];
          console.log(url);
          setBannersObject({ ...bannerObject, banner_image: url });
          setBackdropOpen(false);
        }
        if (502 === imageUpload.status)
          throw "Server Error. Please reload and try again!!";
      } catch (err) { 
        console.log(err);
       
      }
    }
  };

  const handleChange = (name, event) => {
    setBannersObject({ ...bannerObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setBannersObject({
    name: "",
    type: "",
    user_id:"",
    banner_image: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "application/json",
      token: Login.data.token,
    };
    const bodyFormData = new FormData();
    bodyFormData.append("name", bannerObject.name);
    bodyFormData.append("type", bannerObject.type);
    bodyFormData.append("user_id", bannerObject.user_id);
    bodyFormData.append("banner_image", bannerObject.banner_image);
    if (bannerObject._id) {
      try {
        bodyFormData.append("banner_id", bannerObject._id);
        const addStores = await axios({
          method: "post",
          url: editBannerApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        //console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getBannersList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getBannersList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);
  
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }else{
      try {
        const addStores = await axios({
          method: "post",
          url: addbannerApi,
          data: bodyFormData,
          headers: {
            "Content-Type": "multipart/form-data",
            token: Login.data.token,
          },
        });
        //console.log(bodyFormData);
        if (addStores.data.status === 200) {
          getBannersList({ token: Login.data.token });
          setBackdropOpen(false);
          handleClose();
          setErrorType("success");
          setMessage(addStores.data.message);
          setAlert(true);
        } else if (addStores.data.status === 201) {
          getBannersList({ token: Login.data.token });
          setBackdropOpen(false);
          setErrorType("error");
          setMessage(addStores.data.message);
  
          setAlert(true);
        } else {
          setBackdropOpen(false);
          setErrorType("error");
          setMessage("Error!, Please contact your Administrator!!");
          setAlert(true);
        }
      } catch (error) {
        console.log(error);
      }
    }
   
   
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

//  console.log(bannerObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Banner Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <TextField
                id="outlined-textarea"
                label="Name"
                placeholder="Enter Name"
                multiline
                fullWidth
                value={bannerObject.name}
                onChange={(e) => handleChange("name", e)}
                style={{ margin: 5 }}
              />
              <FormControl fullWidth style={{ margin: 5 }}>
                <InputLabel id="demo-simple-select-label">Type</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={bannerObject.type}
                  label="Type"
                  onChange={(e) => handleChange("type", e)}
                >
                  <MenuItem value={1}>Flex</MenuItem>
                  <MenuItem value={2}>Carousel</MenuItem>
                </Select>
              </FormControl>
             
              <input
                    style={{
                      marginLeft: 10,
                    }}
                    type="file"
                    accept="image/*"
            
                    onChange={(evt) => onImageUpload(evt)}
                  />
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login,Banners }) => ({ Login,Banners });

const mapDispatchToProps = (dispatch) => ({
  getBannersList: (object) => dispatch(loadBanners(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(BannersModal);
