import * as React from "react";
import "./sidebar.css"
import { styled } from "@mui/material/styles";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import {
  Icon,
  ListItem,
  Toolbar,
  List,
  CssBaseline,
  Box,
  ListItemIcon,
  ListItemText,
  Avatar,
  Badge,
  IconButton,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { deepOrange } from "@mui/material/colors";
import NotificationsIcon from "@mui/icons-material/Notifications";
import logo from "../../assets/logos/skdigi-logo.png";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Dashboard from "../dashboard";
// import Product from "../product";
// import Categories from "../categories";
import Banners from "../banners";
// import Offers from "../offers";
import Doctor from "../doctor"
import Employee from "../employee"
 import Specialization from "../specialization"
import Patient from "../patient"
import Hospital from "../hospital"
// import Orders from "../orders";
// import Stores from "../stores";

const drawerWidth = 240;

const sidebar = [
  {
    id: 1,
    name: "Dashboard",
    icon: "dashboard",
    path: "/dashboard",
  },
  {
    id: 2,
    name: "Doctor",
    icon: "add_moderator",
    path: "/doctor",
  },
  {
    id: 3,
    name: "Patient",
    icon: "wheelchair_pickup",
    path: "/patient",
  },
  {
    id: 4,
    name: "Specialization",
    icon: "military_tech",
    path: "/specialization",
  },
  {
    id: 5,
    name: "Hospital",
    icon: "location_city",
    path: "/hospital",
  },
  {
    id: 6,
    name: "Employee",
    icon: "person_pin",
    path: "/employee",
  },
  {
    id: 7,
    name: "Banner",
    icon: "add_photo_alternate",
    path: "/banner",
  }
];

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  margin:"3px 0px 0px 1px",
  border:"0.1px solid rgb(240, 240, 245)",
  background:"rgba(255, 255, 255, 0.51)",
  // boxShadow: "5px 6px 9px 4px #888888",
  // filter: "blur(0.5px) saturate(150%)",
  height: "99vh",
  overflowX: "hidden",
  borderRadius:"10px",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  height: "99vh",
  overflowX: "hidden",
  borderRadius:"10px",
  margin:"3px 0px 0px 1px",
  border:"0.1px solid rgb(240, 240, 245)",
  background:"rgba(255, 255, 255, 0.51)",
  // filter: "blur(0.5px) saturate(150%)",
  // height: "100vh",
  
  width: `calc(${theme.spacing(7)} + 18px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(9)} + 18px)`,
  },
});

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  backgroundColor: "transparent", 
  backdropFilter: "blur(3px)",
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
  ...(!open && {
    marginLeft: drawerWidth,
    
    width: `calc(100% - ${90}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 10,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

export default function Sidebar(props) {
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  return (
    <Box  sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar  position="fixed" open={open} elevation={0}>
        <Toolbar style={styles.toolbar}>
          <IconButton >
            <SearchIcon color="action" sx={{ fontSize: 30 }} />
          </IconButton>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "6%",
           
            }}
          >
            <IconButton>
              <Badge badgeContent={4} color="primary">
                <NotificationsIcon color="action" sx={{ fontSize: 30 }} />
              </Badge>
            </IconButton>
            <IconButton>
              <Avatar sx={{ bgcolor: deepOrange[500], width: 30, height: 30 }}>
                N
              </Avatar>
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
      
      <Drawer
        // sx={{
        //   width: drawerWidth,
        //   flexShrink: 0,
        //   "& .MuiDrawer-paper": {
        //     width: drawerWidth,
        //     boxSizing: "border-box",
        //   },
        // }}
        onMouseOver={handleDrawerOpen}
        onMouseLeave={handleDrawerClose}
        open={open}
        variant="permanent"
        anchor="left"
        
      >
        <Toolbar >
          <img src={logo} alt="logo"  style={{ height: 50,zIndex:"1" }} />
        </Toolbar>
        <List style={{ marginLeft: 20,zIndex:"1" }}>
          {sidebar.map((text, index) => (
            <ListItem
              button
              key={text.id}
              style={styles.listItem}
              onClick={() => (window.location.pathname = text.path)}
            >
              <ListItemIcon>
                <Icon>{text.icon}</Icon>
              </ListItemIcon>
              <ListItemText primary={text.name} />
            </ListItem>
          ))}
        </List>
      </Drawer>
   
  

      <Box
        component="main"
        sx={{ flexGrow: 1, bgcolor: "background.default", p: 5 }}
      >
        <Router>
          {/* <Switch> */}
          <Route exact path="/dashboard" component={Dashboard} />
          <Route exact path="/doctor" component={Doctor} />
          <Route exact path="/specialization" component={Specialization} />
          <Route exact path="/patient" component={Patient} />
          <Route exact path="/hospital" component={Hospital} />
          <Route exact path="/employee" component={Employee} />
          <Route exact path="/banner" component={Banners} />
          {/* <Route exact path="/offer" component={Offers} />
          <Route exact path="/orders" component={Orders} /> */}
          {/* </Switch> */}
        </Router>
      </Box>
    </Box>
  );
}

const styles = {
  listItem: {
    paddingBottom: 20,
    paddingTop: 20,
  },
  toolbar: {
    display: "flex",
    justifyContent: "space-between",
    width: "97%",
  },
};
