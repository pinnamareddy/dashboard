import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
import { loadCategories } from "../../store/actions/categories";
import CategoryModel from "./categoryModal";

const headers = [
  {
    id: "category_name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "category_subtitle",
    numeric: false,
    disablePadding: false,
    label: "Subtitle",
  },
  // {
  //   id: "order_status",
  //   numeric: true,
  //   disablePadding: false,
  //   label: "Order Status",
  // },
  {
    id: "Created_on",
    numeric: true,
    disablePadding: false,
    label: "Created",
  },
  // {
  //   id: "phone",
  //   numeric: true,
  //   disablePadding: false,
  //   label: "Phone",
  // },
];

export class Categories extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
    };
  }

  componentDidMount() {
    const { getcategoriesList, Login } = this.props;
    getcategoriesList({ token: Login.data.token });
  }

  ordersClick = (value) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      }
    });
  };

  handleModal = (value) => {
    this.setState({ open: value });
  };

  render() {
    const { Categories } = this.props;
    const { add, open } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Categories"
          headCell={headers}
          data={Categories.data}
          add={this.ordersClick}
          edit={this.ordersClick}
          del={this.ordersClick}
        />
        {add && (
          <CategoryModel openModel={open} handleModelClose={this.handleModal} />
        )}
      </div>
    );
  }
}

const mapStateToProps = ({ Categories, Login }) => ({ Categories, Login });

const mapDispatchToProps = (dispatch) => ({
  getcategoriesList: (object) => dispatch(loadCategories(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Categories);
