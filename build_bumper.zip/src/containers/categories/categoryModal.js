import * as React from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addCategoryApi } from "../../constant";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
import { loadCategories } from "../../store/actions/categories";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function CategoryModel(props) {
  const [categoriesObject, setCategoriesObject] = React.useState({
    category_name: "",
    category_subtitle: "",
    category_img: {},
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getcategoriesList } = props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const onImageUpload = async (event) => {
    let files = Object.values(event.target.files);

    if (files[0] && files[0].size > 1000000) {
      this.setState({
        errorType: "error",
        message: "This image size is more than 1mb.",
        alert: true,
        backDrop: false,
      });
    } else {
      let bodyFormData = new FormData();
      bodyFormData.append("files", files[0]);
      setCategoriesObject({ ...categoriesObject, category_img: bodyFormData });
    }
  };

  const handleChange = (name, event) => {
    setCategoriesObject({ ...categoriesObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setCategoriesObject({
      category_name: "",
      category_subtitle: "",
      category_img: {},
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "application/json",
      token: Login.data.token,
    };
    try {
      const addCategory = await axios.post(
        addCategoryApi,
        {
          category_name: categoriesObject.category_name,
          category_subtitle: categoriesObject.category_subtitle,
          category_img: categoriesObject.category_img,
        },
        { headers: headers }
      );
      console.log(addCategory);
      if (addCategory.data.status === 200) {
        getcategoriesList({ token: Login.data.token });
        setBackdropOpen(false);
        handleClose();
        setErrorType("success");
        setMessage(addCategory.data.message);
        setAlert(true);
      } else if (addCategory.data.status === 201) {
        setBackdropOpen(false);
        setErrorType("error");
        setMessage(addCategory.data.message);
        setAlert(true);
      } else {
        setBackdropOpen(false);
        setErrorType("error");
        setMessage("Error!, Please contact your Administrator!!");
        setAlert(true);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  console.log(categoriesObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            C
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <TextField
                id="outlined-textarea"
                label="Name"
                placeholder="Enter name"
                multiline
                fullWidth
                value={categoriesObject.category_name}
                onChange={(e) => handleChange("category_name", e)}
                style={{ margin: 10 }}
              />

              <TextField
                id="outlined-textarea"
                label="Sub-Title"
                placeholder="Enter sub-title"
                multiline
                rows={4}
                fullWidth
                value={categoriesObject.category_subtitle}
                onChange={(e) => handleChange("category_subtitle", e)}
                style={{ margin: 10 }}
              />
              <input
                style={{
                  marginRight: -50,
                }}
                type="file"
                accept="image/*"
                onChange={(evt) => onImageUpload(evt)}
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login }) => ({ Login });

const mapDispatchToProps = (dispatch) => ({
  getcategoriesList: (object) => dispatch(loadCategories(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CategoryModel);
