import React, { Component } from "react";
import { connect } from "react-redux";
import Datatable from "../../components/datatable";
// import { loadStores } from "../../store/actions/stores";
import StoresModal from "./storesModal";

const headers = [
  {
    id: "store_display_name",
    numeric: false,
    disablePadding: true,
    label: "Name",
  },
  {
    id: "store_description",
    numeric: false,
    disablePadding: false,
    label: "Description",
  },
  {
    id: "city",
    numeric: false,
    disablePadding: false,
    label: "City",
  },
  {
    id: "pin_code",
    numeric: false,
    disablePadding: false,
    label: "Pincode",
  },
  {
    id: "createddt",
    numeric: true,
    disablePadding: false,
    label: "Created on",
  },
];

export class Stores extends Component {
  constructor(props) {
    super(props);
    this.state = {
      add: false,
      edit: false,
      del: false,
      open: false,
    };
  }

  componentDidMount() {
    // const { getStoreList, Login } = this.props;
    // getStoreList({ token: Login.data.token });
  }

  ordersClick = (value) => {
    this.setState({ [value]: true }, () => {
      if (value === "add") {
        this.setState({ open: true });
      }
    });
  };

  handleModal = (value) => {
    this.setState({ open: value });
  };

  render() {
    const { Store } = this.props;
    const { add, open } = this.state;
    return (
      <div style={{ marginTop: 30 }}>
        <Datatable
          name="Employee"
          headCell={headers}
          data={Store.data}
          add={this.ordersClick}
          edit={this.ordersClick}
          del={this.ordersClick}
        />
        {add && (
          <StoresModal openModel={open} handleModelClose={this.handleModal} />
        )}
      </div>
    );
  }
}

const mapStateToProps = ({ Store, Login }) => ({ Store, Login });

const mapDispatchToProps = (dispatch) => ({
  // getStoreList: (object) => dispatch(loadStores(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Stores);
