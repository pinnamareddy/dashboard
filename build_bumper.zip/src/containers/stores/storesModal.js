import React from "react";
import PropTypes from "prop-types";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";
import {
  styled,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import axios from "axios";
import { connect } from "react-redux";
import { addStoresApi } from "../../constant";
// import { loadStores } from "../../store/actions/stores";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
// web.cjs is required for IE11 support
import { useSpring, animated } from "react-spring";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Typography } from "@mui/material";

const Fade = React.forwardRef(function Fade(props, ref) {
  const { in: open, children, onEnter, onExited, ...other } = props;
  const style = useSpring({
    from: { opacity: 0 },
    to: { opacity: open ? 1 : 0 },
    onStart: () => {
      if (open && onEnter) {
        onEnter();
      }
    },
    onRest: () => {
      if (!open && onExited) {
        onExited();
      }
    },
  });

  return (
    <animated.div ref={ref} style={style} {...other}>
      {children}
    </animated.div>
  );
});

Fade.propTypes = {
  children: PropTypes.element,
  in: PropTypes.bool.isRequired,
  onEnter: PropTypes.func,
  onExited: PropTypes.func,
};

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

const BootstrapDialogTitle = (props) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {/* {onClose ? ( */}
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={{
          position: "absolute",
          right: 8,
          top: 8,
          color: (theme) => theme.palette.grey[500],
        }}
      >
        <CloseIcon />
      </IconButton>
      {/* ) : null} */}
    </DialogTitle>
  );
};

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

function StoresModal(props) {
  const [storesObject, setStoresObject] = React.useState({
    name: "",
    email: "",
    store_display_name: "",
    store_url: "",
    mobile: "",
    password: "",
    street: "",
    city: "",
    pin_code: "",
    state: "",
    latitude: "",
    longitude: "",
    store_description: "",
    account_number: "",
    bank_ifc_code: "",
    bank_account_name: "",
    commission: "",
    tax_name: "",
    GST_number: "",
    PAN_number: "",
    logo: "",
    card_id: "",
    address_proof: "",
  });
  const [backdropOpen, setBackdropOpen] = React.useState(false);
  const [alert, setAlert] = React.useState(false);
  const [errorType, setErrorType] = React.useState("");
  const [message, setMessage] = React.useState("");
  const { openModel, handleModelClose, getStoresList } = props;
  const vertical = "bottom";
  const horizontal = "center";
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const onImageUpload = async (event) => {
    let files = Object.values(event.target.files);

    if (files[0] && files[0].size > 1000000) {
      this.setState({
        errorType: "error",
        message: "This image size is more than 1mb.",
        alert: true,
        backDrop: false,
      });
    } else {
      let bodyFormData = new FormData();
      bodyFormData.append("files", files[0]);
      setStoresObject({ ...storesObject, category_img: bodyFormData });
    }
  };

  const handleChange = (name, event) => {
    setStoresObject({ ...storesObject, [name]: event.target.value });
  };

  const handleClose = () => {
    handleModelClose(false);
    setStoresObject({
      name: "",
      email: "",
      store_display_name: "",
      store_url: "",
      mobile: "",
      password: "",
      street: "",
      city: "",
      pin_code: "",
      state: "",
      latitude: "",
      longitude: "",
      store_description: "",
      account_number: "",
      bank_ifc_code: "",
      bank_account_name: "",
      commission: "",
      tax_name: "",
      GST_number: "",
      PAN_number: "",
      logo: "",
      card_id: "",
      address_proof: "",
    });
  };

  const handleSave = async () => {
    setBackdropOpen(true);
    const { Login } = props;
    const headers = {
      "Content-Type": "multipart/form-data",
      token: Login.data.token,
    };

    const data = {
      name: storesObject.name,
      email: storesObject.email,
      store_display_name: storesObject.store_display_name,
      store_url: storesObject.store_url,
      mobile: storesObject.mobile,
      password: storesObject.password,
      street: storesObject.street,
      city: storesObject.city,
      pin_code: storesObject.pin_code,
      state: storesObject.state,
      latitude: storesObject.latitude,
      longitude: storesObject.longitude,
      store_description: storesObject.store_description,
      account_number: storesObject.account_number,
      bank_ifc_code: storesObject.bank_ifc_code,
      bank_account_name: storesObject.bank_account_name,
      commission: storesObject.commission,
      tax_name: storesObject.tax_name,
      GST_number: storesObject.GST_number,
      PAN_number: storesObject.PAN_number,
      logo: "",
      card_id: "",
      address_proof: "",
    };

    const bodyFormData = new FormData();
    bodyFormData.append("name", storesObject.name);
    bodyFormData.append("email", storesObject.email);
    bodyFormData.append("store_display_name", storesObject.store_display_name);
    bodyFormData.append("store_url", storesObject.store_url);
    bodyFormData.append("mobile", storesObject.mobile);
    bodyFormData.append("password", storesObject.password);
    bodyFormData.append("street", storesObject.street);
    bodyFormData.append("city", storesObject.city);
    bodyFormData.append("pin_code", storesObject.pin_code);
    bodyFormData.append("state", storesObject.state);
    bodyFormData.append("latitude", storesObject.latitude);
    bodyFormData.append("longitude", storesObject.longitude);
    bodyFormData.append("store_description", storesObject.store_description);
    bodyFormData.append("account_number", storesObject.account_number);
    bodyFormData.append("bank_ifc_code", storesObject.bank_ifc_code);
    bodyFormData.append("bank_account_name", storesObject.bank_account_name);
    bodyFormData.append("commission", storesObject.commission);
    bodyFormData.append("tax_name", storesObject.tax_name);
    bodyFormData.append("GST_number", storesObject.GST_number);
    bodyFormData.append("PAN_number", storesObject.PAN_number);
    bodyFormData.append("logo", storesObject.logo);
    bodyFormData.append("card_id", storesObject.card_id);
    bodyFormData.append("address_proof", storesObject.address_proof);
    try {
      const addStores = await axios({
        method: "post",
        url: addStoresApi,
        data: bodyFormData,
        headers: {
          "Content-Type": "multipart/form-data",
          token: Login.data.token,
        },
      });
      console.log(addStores);
      if (addStores.data.status === 200) {
        // getStoresList({ token: Login.data.token });
        setBackdropOpen(false);
        handleClose();
        setErrorType("success");
        setMessage(addStores.data.message);
        setAlert(true);
      } else if (addStores.data.status === 201) {
        // getStoresList({ token: Login.data.token });
        setBackdropOpen(false);
        handleClose();
        setErrorType("success");
        setMessage("Store added Successfully!");
        setAlert(true);
      } else {
        setBackdropOpen(false);
        setErrorType("error");
        setMessage("Error!, Please contact your Administrator!!");
        setAlert(true);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const themeColor = createTheme({
    palette: {
      neutral: {
        main: "#424242",
        contrastText: "#fff",
      },
    },
  });

  console.log(storesObject);

  return (
    <div>
      <BootstrapDialog
        fullWidth
        aria-labelledby="spring-modal-title"
        aria-describedby="spring-modal-description"
        open={openModel}
        maxWidth="md"
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        fullScreen={fullScreen}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openModel}>
          <BootstrapDialogTitle onClose={handleClose}>
            Employee Details
          </BootstrapDialogTitle>
          <DialogContent>
            <Box style={{ margin: 10 }}>
              <Grid container spacing={2}>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Name"
                    placeholder="Enter name"
                    multiline
                    fullWidth
                    value={storesObject.name}
                    onChange={(e) => handleChange("name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Store Description"
                    placeholder="Enter store description"
                    multiline
                    rows={4.4}
                    fullWidth
                    value={storesObject.store_description}
                    onChange={(e) => handleChange("store_description", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Latitude"
                    placeholder="Enter latitude"
                    multiline
                    fullWidth
                    value={storesObject.latitude}
                    onChange={(e) => handleChange("latitude", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Email"
                    placeholder="Enter email"
                    multiline
                    fullWidth
                    value={storesObject.email}
                    onChange={(e) => handleChange("email", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Mobile Number"
                    placeholder="Enter mobile number"
                    multiline
                    fullWidth
                    value={storesObject.mobile}
                    onChange={(e) => handleChange("mobile", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="City"
                    placeholder="Enter city"
                    multiline
                    fullWidth
                    value={storesObject.city}
                    onChange={(e) => handleChange("city", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="State"
                    placeholder="Enter state"
                    multiline
                    fullWidth
                    value={storesObject.state}
                    onChange={(e) => handleChange("state", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Bank Account Name"
                    placeholder="Enter bank account name"
                    multiline
                    fullWidth
                    value={storesObject.bank_account_name}
                    onChange={(e) => handleChange("bank_account_name", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Tax Name"
                    placeholder="Enter tax name"
                    multiline
                    fullWidth
                    value={storesObject.tax_name}
                    onChange={(e) => handleChange("tax_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="GST Number"
                    placeholder="Enter GST number"
                    multiline
                    fullWidth
                    value={storesObject.GST_number}
                    onChange={(e) => handleChange("GST_number", e)}
                    style={{ margin: 10 }}
                  />
                </Grid>
                <Grid item xs={6} md={6}>
                  <TextField
                    id="outlined-textarea"
                    label="Store Display Name"
                    placeholder="Enter store display name"
                    multiline
                    fullWidth
                    value={storesObject.store_display_name}
                    onChange={(e) => handleChange("store_display_name", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Store Url"
                    placeholder="Enter store url"
                    multiline
                    fullWidth
                    value={storesObject.store_url}
                    onChange={(e) => handleChange("store_url", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Commission"
                    placeholder="Enter commission"
                    multiline
                    fullWidth
                    value={storesObject.commission}
                    onChange={(e) => handleChange("commission", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Longitude"
                    placeholder="Enter longitude"
                    multiline
                    fullWidth
                    value={storesObject.longitude}
                    onChange={(e) => handleChange("longitude", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Password"
                    placeholder="Enter password"
                    multiline
                    fullWidth
                    value={storesObject.password}
                    onChange={(e) => handleChange("password", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Street"
                    placeholder="Enter street"
                    multiline
                    fullWidth
                    value={storesObject.street}
                    onChange={(e) => handleChange("street", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Pincode"
                    placeholder="Enter pincode"
                    multiline
                    fullWidth
                    value={storesObject.pin_code}
                    onChange={(e) => handleChange("pin_code", e)}
                    style={{ margin: 10 }}
                  />

                  <TextField
                    id="outlined-textarea"
                    label="Account Number"
                    placeholder="Enter account number"
                    multiline
                    fullWidth
                    value={storesObject.account_number}
                    onChange={(e) => handleChange("account_number", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="Bank IFSC Code"
                    placeholder="Enter bank ifc code"
                    multiline
                    fullWidth
                    value={storesObject.bank_ifc_code}
                    onChange={(e) => handleChange("bank_ifc_code", e)}
                    style={{ margin: 10 }}
                  />
                  <TextField
                    id="outlined-textarea"
                    label="PAN Number"
                    placeholder="Enter PAN number"
                    multiline
                    fullWidth
                    value={storesObject.PAN_number}
                    onChange={(e) => handleChange("PAN_number", e)}
                    style={{ margin: 10 }}
                  />
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions>
            <ThemeProvider theme={themeColor}>
              <Button onClick={handleClose} variant="contained" color="neutral">
                Close
              </Button>
            </ThemeProvider>
            <Button
              onClick={handleSave}
              autoFocus
              variant="contained"
              color="success"
            >
              Save
            </Button>
          </DialogActions>
          <Backdrop
            // sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 3 }}
            open={backdropOpen}
            onClick={handleClose}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Fade>
      </BootstrapDialog>

      <Snackbar
        open={alert}
        autoHideDuration={6000}
        onClose={() => setAlert(false)}
        anchorOrigin={{ vertical, horizontal }}
      >
        <Alert onClose={() => setAlert(false)} severity={errorType}>
          {message}
        </Alert>
      </Snackbar>
    </div>
  );
}

const mapStateToProps = ({ Login }) => ({ Login });

const mapDispatchToProps = (dispatch) => ({
  // getStoresList: (object) => dispatch(loadStores(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(StoresModal);
