import React, { useEffect, useRef } from "react";
import {
  TextField,
  OutlinedInput,
  InputAdornment,
  IconButton,
  FormControl,
  InputLabel,
  Button,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import ErrorIcon from "@mui/icons-material/Error";
import { loadLogin } from "../../store/actions/login";
import { connect } from "react-redux";

const useStyles = makeStyles({
  root: {
    [`& fieldset`]: {
      borderRadius: 10,
    },
  },
});
function Signin(props) {
  const [values, setValues] = React.useState({
    email: "",
    password: "",
    showPassword: false,
  });

  const { Login } = props;

  const usePrevious = (value) => {
    const ref = useRef();
    useEffect(() => {
      ref.current = value;
    });
    return ref.current;
  };

  const prevLogin = usePrevious({ Login });

  useEffect(() => {
    if (prevLogin && prevLogin.Login.loading !== Login.loading) {
      if (Login.data && Login.data.status === 200) {
        window.location.pathname = "/dashboard";
      }
    }
  }, [prevLogin, Login]);

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleLogin = () => {
    const { setLogin } = props;
    setLogin({ email: values.email, password: values.password });
  };

  const classes = useStyles(props);
  return (
    <div style={styles.signIn}>
      <p style={styles.admin}>
        Super Admin Login, <span style={styles.adminclick}>Click here.</span>
      </p>
      <h2 style={styles.header}>Sign in to Dashboard</h2>
      <p style={styles.para}>Enter your details below.</p>
      <div style={styles.forgot}>
        <ErrorIcon style={styles.infoicon} />
        <p style={styles.forgotText}>
          Forgot password? Please contact the Adminstrator.
        </p>
      </div>
      {/* ------------ Login Form ------------- */}
      <div style={styles.login}>
        <TextField
          className={classes.root}
          id="inputRounded"
          label="Email address"
          variant="outlined"
          value={values.email}
          inputProps={{
            autoComplete: "new-password",
          }}
          onChange={handleChange("email")}
          fullWidth
        />
        <FormControl className={classes.root} variant="outlined" fullWidth>
          <InputLabel htmlFor="outlined-adornment-password">
            Password
          </InputLabel>
          <OutlinedInput
            inputProps={{
              autoComplete: "new-password",
            }}
            id="outlined-adornment-password"
            type={values.showPassword ? "text" : "password"}
            value={values.password}
            onChange={handleChange("password")}
            fullWidth
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {values.showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
        </FormControl>
        <Button variant="contained" style={styles.button} onClick={handleLogin}>
          Login
        </Button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "space-between",
    margin: "1.8%",
  },
  signIn: {
    width: "50%",
    textAlign: "left",
    margin: "6% 0% 10% 5%",
  },
  header: {
    margin: "0.6em 0em 0.4em 0em",
  },
  para: {
    margin: 1,
    color: "#83909B",
  },
  login: {
    padding: "20px 0px 50px 0px",
    width: "70%",
    height: 200,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  button: {
    backgroundColor: "#002040",
    padding: 10,
    borderRadius: 10,
    fontWeight: "700",
  },
  admin: {
    fontSize: 15,
    textAlign: "right",
    fontWeight: "500",
  },
  adminclick: {
    color: "#ea5a35",
    fontWeight: "700",
  },
  forgot: {
    display: "flex",
    marginTop: 10,
    backgroundColor: "#d0f2ff",
    width: "70%",
    padding: 3,
    borderRadius: 10,
    alignItems: "center",
    textAlign: "center",
  },
  forgotText: {
    color: "#002040",
    fontWeight: "600",
  },
  infoicon: {
    padding: "10px 20px",
    color: "#11b5c8",
  },
};

const mapStateToProps = ({ Login }) => ({ Login });

const mapDispatchToProps = (dispatch) => ({
  setLogin: (object) => dispatch(loadLogin(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Signin);
