import { combineReducers } from "redux";
import LoginReducer from "./login";
import BannerReducer from "./banners";
import DoctorsReducer from "./doctors";
import PatientReducer from "./patients";
import SpecializationReducer from "./specializations";
import HospitalReducer from "./hospitals";
import EmployeeReducer from "./employees";
const rootReducer = combineReducers({
  Login: LoginReducer,
  Banners: BannerReducer,
  Doctors: DoctorsReducer,
  Patients: PatientReducer,
  Specializations: SpecializationReducer,
  Hospitals: HospitalReducer,
  Employees: EmployeeReducer,
});

export default rootReducer;
