import { HOSPITALS } from "../constants";

const initialState = {
  loading: false,
  data: [],
  error: "",
};

const reducer = (state = initialState, action) => {
  
  switch (action.type) {
    case HOSPITALS.LOAD:
      return {
        ...state,
        loading: true,
      };
    case HOSPITALS.LOAD_SUCCESS:
      return {
        loading: false,
        data: action.hospitals,
        error: "",
      };
    case HOSPITALS.LOAD_FAIL:
      return {
        loading: false,
        data: [],
        error: action.error,
      };
    default:
      return state;
  }
};
export default reducer;
