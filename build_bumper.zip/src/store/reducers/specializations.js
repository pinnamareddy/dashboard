import { SPECIALIZATIONS } from "../constants";

const initialState = {
  loading: false,
  data: [],
  error: "",
};

const reducer = (state = initialState, action) => {
  // console.log(action.type)
  switch (action.type) {
    case SPECIALIZATIONS.LOAD:
      return {
        ...state,
        loading: true,
      };
    case SPECIALIZATIONS.LOAD_SUCCESS:
      return {
        loading: false,
        data: action.specializations,
        error: "",
      };
    case SPECIALIZATIONS.LOAD_FAIL:
      return {
        loading: false,
        data: [],
        error: action.error,
      };
    default:
      return state;
  }
};
export default reducer;
