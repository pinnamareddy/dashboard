import { BANNERS } from "../constants";

const initialState = {
  loading: false,
  data: [],
  error: "",
};

const reducer = (state = initialState, action) => {
  // console.log(action.type)
  switch (action.type) {
    case BANNERS.LOAD:
      return {
        ...state,
        loading: true,
      };
    case BANNERS.LOAD_SUCCESS:
      return {
        loading: false,
        data: action.banners,
        error: "",
      };
    case BANNERS.LOAD_FAIL:
      return {
        loading: false,
        data: [],
        error: action.error,
      };
    default:
      return state;
  }
};
export default reducer;
