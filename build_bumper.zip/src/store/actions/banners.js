import { BANNERS } from "../constants";

const loadBanners = (banners) => ({
  type: BANNERS.LOAD,
  banners,
});

const setBanners = (banners) => ({
  type: BANNERS.LOAD_SUCCESS,
  banners,
});

const setError = (error) => ({
  type: BANNERS.LOAD_FAIL,
  error,
});

export { loadBanners, setBanners, setError };
