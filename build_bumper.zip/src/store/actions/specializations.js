import { SPECIALIZATIONS } from "../constants";

const loadSpecializations = (specializations) => ({
  type: SPECIALIZATIONS.LOAD,
  specializations,
});

const setSpecializations = (specializations) => ({
  type: SPECIALIZATIONS.LOAD_SUCCESS,
  specializations,
});

const setError = (error) => ({
  type: SPECIALIZATIONS.LOAD_FAIL,
  error,
});

export { loadSpecializations, setSpecializations, setError };
