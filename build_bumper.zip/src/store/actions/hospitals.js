import { HOSPITALS } from "../constants";

const loadHospitals = (hospitals) => ({
  type: HOSPITALS.LOAD,
  hospitals,
});

const setHospitals = (hospitals) => ({
  type: HOSPITALS.LOAD_SUCCESS,
  hospitals,
});

const setError = (error) => ({
  type: HOSPITALS.LOAD_FAIL,
  error,
});

export { loadHospitals, setHospitals, setError };
