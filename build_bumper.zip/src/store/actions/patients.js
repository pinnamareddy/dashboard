import { PATIENTS } from "../constants";

const loadPatients = (patients) => ({
  type: PATIENTS.LOAD,
  patients,
});

const setPatients = (patients) => ({
  type: PATIENTS.LOAD_SUCCESS,
  patients,
});

const setError = (error) => ({
  type: PATIENTS.LOAD_FAIL,
  error,
});

export { loadPatients, setPatients, setError };
