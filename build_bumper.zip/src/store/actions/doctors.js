import { DOCTORS } from "../constants";

const loadDoctors = (doctors) => ({
  type: DOCTORS.LOAD,
  doctors,
});

const setDoctors = (doctors) => ({
  type: DOCTORS.LOAD_SUCCESS,
  doctors,
});

const setError = (error) => ({
  type: DOCTORS.LOAD_FAIL,
  error,
});

export { loadDoctors, setDoctors, setError };
