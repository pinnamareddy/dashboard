import axios from "axios";
import {
  bannerListApi,
  doctorListApi,
  patientListApi,
  hospitalListApi,
  specializationListApi,
  employeeListApi,
  loginUrl,
  tokenUrl,
} from "../../constant.js";
import moment from "moment";

const token = async () => {
  try {
    const tokenApi = await axios.get(tokenUrl);
    return tokenApi.data.token;
  } catch (error) {
    console.log(error);
  }
};

const login = async (user) => {
  const tokenValue = await token();
  const headers = {
    "Content-Type": "application/json",
    token: tokenValue,
  };
  const email = user.email;
  const password = user.password;
  try {
    const logindata = await axios.post(
      loginUrl,
      { email: email, password: password },
      { headers: headers }
    );
    return logindata.data;
  } catch (error) {
    console.log(error);
  }
};

const fetchDoctors = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const doctorsApi = await axios.get(doctorListApi, {
      headers: headers,
    });

    doctorsApi.data.data.map((it) => {
      return (it.createddt = moment(it.createddt).format("DD MMM YYYY"));
    });

    let doctors = await doctorsApi.data.data;
    return doctors;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};
const fetchPatients = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const patientsApi = await axios.get(patientListApi, {
      headers: headers,
    });

    patientsApi.data.data.map((it) => {
      return (it.createddt = moment(it.createddt).format("DD MMM YYYY"));
    });

    let patients = await patientsApi.data.data;
    return patients;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};
const fetchSpecializations = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const specializationsApi = await axios.get(specializationListApi, {
      headers: headers,
    });

    console.log(specializationsApi);

    // specializationsApi.data.data.map((it) => {
    //   return (it.createddt = moment(it.createddt).format("DD MMM YYYY"));
    // });
    let specializations = await specializationsApi.data.data;
    return specializations;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};

const fetchHospitals = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const hospitalsApi = await axios.get(hospitalListApi, {
      headers: headers,
    });

    // hospitalsApi.data.data.map((it) => {
    //   return (it.createddt = moment(it.createddt).format("DD MMM YYYY"));
    // });

    let hospitals = await hospitalsApi.data.data;
    return hospitals;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};
const fetchEmployees = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const employeesApi = await axios.get(employeeListApi, {
      headers: headers,
    });

    // employeesApi.data.data.map((it) => {
    //   return (it.createddt = moment(it.createddt).format("DD MMM YYYY"));
    // });

    let employees = await employeesApi.data.data;
    return employees;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};

const fetchBanners = async (token) => {
  const headers = {
    "Content-Type": "application/json",
    token: token.token,
  };
  try {
    const bannersApi = await axios.get(bannerListApi, {
      headers: headers,
    });

    bannersApi.data.data.map((it) => {
      return (it.created_on = moment(it.created_on).format("DD MMM YYYY"));
    });

    let banners = await bannersApi.data.data;
    return banners;
  } catch (error) {
    const data = {
      error: "",
    };
    data.error = error.response.data;
    return data;
  }
};


export {
  login,
  fetchDoctors,
  fetchPatients,
  fetchBanners,
  fetchSpecializations,
  fetchHospitals,
  fetchEmployees,
};
