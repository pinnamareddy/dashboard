import { all } from "redux-saga/effects";
import Login from "./login";
import Banners from "./banners";
import Doctors from "./doctors";
import Patients from "./patients";
import Specializations from "./specializatons";
import Hospitals from "./hospitals";
import Employees from "./employees"
export default function* rootSaga() {
  yield all([
    Login(),
    Banners(),
    Doctors(),
    Patients(),
    Specializations(),
    Hospitals(),
    Employees(),
  ]);
}
