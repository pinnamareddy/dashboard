import { put, call, takeEvery } from "redux-saga/effects";

import { setHospitals, setError } from "../actions/hospitals";
import { HOSPITALS } from "../constants";
import { fetchHospitals } from "../api";

export function* handleDoctorsLoad(action) {
  try {
    const hospitals = yield call(fetchHospitals, action.hospitals);
    if (hospitals && hospitals.error) throw hospitals.error;
    yield put(setHospitals(hospitals));
  } catch (error) {
    yield put(setError(error));
  }
}

export default function* watchDoctorsLoad() {
  yield takeEvery(HOSPITALS.LOAD, handleDoctorsLoad);
}
