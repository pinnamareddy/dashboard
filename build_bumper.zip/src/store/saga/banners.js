import { put, call, takeEvery } from "redux-saga/effects";

import { setBanners, setError } from "../actions/banners";
import { BANNERS } from "../constants";
import { fetchBanners } from "../api";

export function* handleBannersLoad(action) {
  try {
    const banners = yield call(fetchBanners, action.banners);
    if (banners && banners.error) throw banners.error;
    yield put(setBanners(banners));
  } catch (error) {
    yield put(setError(error));
  }
}

export default function* watchBannersLoad() {
  yield takeEvery(BANNERS.LOAD, handleBannersLoad);
}
