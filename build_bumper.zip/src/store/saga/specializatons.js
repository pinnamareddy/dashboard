import { put, call, takeEvery } from "redux-saga/effects";

import { setSpecializations, setError } from "../actions/specializations";
import { SPECIALIZATIONS } from "../constants";
import { fetchSpecializations } from "../api";

export function* handleSpecializationsLoad(action) {
  try {
    const specializations = yield call(fetchSpecializations, action.specializations);
    if (specializations && specializations.error) throw specializations.error;
    yield put(setSpecializations(specializations));
  } catch (error) {
    yield put(setError(error));
  }
}

export default function* watchSpecializationsLoad() {
  yield takeEvery(SPECIALIZATIONS.LOAD, handleSpecializationsLoad);
}
