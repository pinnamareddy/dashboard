import { put, call, takeEvery } from "redux-saga/effects";

import { setPatients, setError } from "../actions/patients";
import { PATIENTS } from "../constants";
import { fetchPatients } from "../api";

export function* handleDoctorsLoad(action) {
  try {
    const patients = yield call(fetchPatients, action.patients);
    if (patients && patients.error) throw patients.error;
    yield put(setPatients(patients));
  } catch (error) {
    yield put(setError(error));
  }
}

export default function* watchDoctorsLoad() {
  yield takeEvery(PATIENTS.LOAD, handleDoctorsLoad);
}
