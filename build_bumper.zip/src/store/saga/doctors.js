import { put, call, takeEvery } from "redux-saga/effects";

import { setDoctors, setError } from "../actions/doctors";
import { DOCTORS } from "../constants";
import { fetchDoctors } from "../api";

export function* handleDoctorsLoad(action) {
  try {
    const doctors = yield call(fetchDoctors, action.doctors);
    if (doctors && doctors.error) throw doctors.error;
    yield put(setDoctors(doctors));
  } catch (error) {
    yield put(setError(error));
  }
}

export default function* watchDoctorsLoad() {
  yield takeEvery(DOCTORS.LOAD, handleDoctorsLoad);
}
