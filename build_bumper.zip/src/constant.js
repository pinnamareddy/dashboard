const baseUrl = "https://skdigi.com/hospital/api/";

export const store_id = "61613bfcfbf630fae8361b0d";

export const uploadImageUrl =
  "https://vast-anchorage-24854.herokuapp.com/http://107.180.105.183:8445/uploadimage";

export const tokenUrl = baseUrl + "tokenGenrate/jwtToken";
export const loginUrl = baseUrl + "adminauth/suadminLogin";

export const imageurl = "https://skdigi.com/images"

export const doctorListApi = baseUrl + "doctor/doctorlist";
export const specializationListApi =
  baseUrl + "specialization/specializationlist";
export const patientListApi = baseUrl + "patient/patientlist";
export const hospitalListApi = baseUrl + "hospital/hospitallist";
export const employeeListApi = baseUrl + "employee/employeelist";
export const bannerListApi = baseUrl + "banner/bannerList";
export const offersListApi = baseUrl + "multiapi/offer/offerList";
export const addCategoryApi = baseUrl + "multiapi/store/createCategory";

export const adddoctorApi = baseUrl + "doctor/adddoctor";
export const editDoctorApi = baseUrl + "doctor/editdoctor";
export const deleteDoctorApi = baseUrl + "doctor/deletedoctor";

export const addpatientApi = baseUrl + "patient/addpatient";
export const editPatientApi = baseUrl + "patient/editpatient";
export const deletePatientApi = baseUrl + "patient/deletepatient";

export const addspecializationApi = baseUrl + "specialization/addspecialization";
export const editSpecializationApi = baseUrl + "specialization/editspecialization";
export const deleteSpecializationApi = baseUrl + "specialization/deletespecialization";

export const addhospitalApi = baseUrl + "hospital/addhospital";
export const editHospitalApi = baseUrl + "hospital/edithospital";
export const deleteHospitalApi = baseUrl + "hospital/deletehospital";

export const addemployeeApi = baseUrl + "employee/addemployee";
export const editEmployeeApi = baseUrl + "employee/editemployee";
export const deleteEmployeeApi = baseUrl + "employee/deleteemployee";

export const addbannerApi = baseUrl + "banner/addbanner";
export const editBannerApi = baseUrl + "banner/editbanner";
export const deleteBannerApi = baseUrl + "banner/deleteBanner";


